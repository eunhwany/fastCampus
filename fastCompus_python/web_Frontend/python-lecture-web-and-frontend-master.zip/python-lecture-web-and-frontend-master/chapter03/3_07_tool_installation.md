# 3-07. 도구 설치

1. [Visual Studio Code](https://code.visualstudio.com/)
   - 익스텐션 설정
     - prettier
     - live server
     - Korean Language Pack
     - HTML snippet
2. [firefox](https://www.mozilla.org/ko/firefox/download)
3. 크롬 익스텐션
   - [web developer](https://chrome.google.com/webstore/detail/web-developer/bfbameneiokkgbdmiekhjnmfkcnldhhm?hl=ko)
   - [whatfont](https://chrome.google.com/webstore/detail/whatfont/jabopobgcpjmedljpbcaablpmlmfcogm?hl=ko)
