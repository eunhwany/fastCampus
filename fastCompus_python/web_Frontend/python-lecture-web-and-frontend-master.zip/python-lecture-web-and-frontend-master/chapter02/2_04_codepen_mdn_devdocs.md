# 2-04. Codepen 사용법, MDN/devdocs.io 검색엔진 추가

1. HTML/CSS 실습: [codepen.io](https://codepen.io/)
1. 학습용 사이트
1. [MDN web docs](https://developer.mozilla.org/)
1. [devdocs.io](https://devdocs.io/)

기타. 검색엔진 추가하는 방법

크롬 설정 - 검색엔진 관리 - 추가 클릭 후

- MDN
  - https://developer.mozilla.org/ko/search?q=%s&w=3&qs=plugin
- devdocs.io
  - devdocs.io
    https://devdocs.io/#q=%s
