# 4-09. side-content 영역 마크업

- 실습 사이트 예제: https://python-lecture-example-1.netlify.com/
- 코드: https://github.com/tinytinystone/python-lecture-example/tree/4_09_main_4_side_markup

(추후 업데이트 예정)
