# 4-06. main(2): main-content 마크업

- 실습 사이트 예제: https://python-lecture-example-1.netlify.com/
- 코드: https://github.com/tinytinystone/python-lecture-example/tree/4_06_main_2_main_markup

(추후 업데이트 예정)

<!-- h1은 로고에서 사용했으므로 여기서는 h2 표제태그 사용.

이메일 주소를 입력해서 전송할 수 있는 부분이 두 개 나옴.
나란히 배치되어 있으므로 여기서도 float를 사용해 보겠다.
클래스이름에는 column, 단의 약자인 col을 넣겠음. 공통되는 속성들은 여기에.
form 태그는 아직 배우기 전이라서 다음 시간에 넣을 것이고 일단은 공란으로.
hr은 선을 그릴 때. border를 이용하는 방법은 위에서 배웠으니 이번에는 hr 태그를 사용해보겠다.

나머지는 단락 요소와 a 요소라서 어렵지 않으므로 따로 작성하지 않겠음.

여기까지 하면 완성.
다음 시간에는 form 요소와 속성에 대해서 간단하게 짚고 넘어가는 시간을 가지겠습니다. -->
