# 4-11. footer 영역 마크업 & 스타일링

- 실습 사이트 예제: https://python-lecture-example-1.netlify.com/
- 코드: https://github.com/tinytinystone/python-lecture-example/tree/4_11_footer_markup_styling

(추후 업데이트 예정)
