# 4-01. Header(1)

- 실습 사이트 예제: https://python-lecture-example-1.netlify.com/
- 코드: https://github.com/tinytinystone/python-lecture-example

이제부터 [예제 사이트](https://python-lecture-example-1.netlify.com/)를 그대로 배껴서 만들어보면서 html, css 를 연습해보는 실습을 진행하겠습니다.

강의는 header, main의 hero-section, main-content, side-content, footer 영역으로 각각 쪼갰고, HTML로 구조를 짜고 CSS로 스타일링을 하는 식으로 분리되어 있습니다. 순서대로 쭉 보시면 되겠습니다.

먼저 이 강의를 보시기전에 직접 만들어보시는 것을 추천 드립니다. 어떻게 하면 똑같이 만들 수 있을지를 생각하시고, 개발자도구를 사용해가면서 제가 한 방법과 직접 만든 방법이 어디가 다른지를 확인해보시면 좋겠습니다.
